import Header from '../components/Header'
import ProductCard from '../components/ProductCard'
import productsData from '../data/products.json'
import { getRecommendations } from '../utils/recommendations'

export default function Home({ recommendations }) {
  return (
    <div>
      <Header />
      <main className="max-w-6xl mx-auto p-6">
        <section className="bg-gradient-to-r from-blue-50 to-white rounded-lg p-8 mb-6">
          <h1 className="text-3xl font-bold">OfertasIA — As melhores ofertas do Brasil</h1>
          <p className="mt-2 text-gray-600">Comparamos preços automaticamente e encontramos as melhores promoções para você.</p>
        </section>

        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Ofertas em destaque</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {productsData.slice(0,3).map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>

        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Recomendadas para você</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {recommendations.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>

      </main>
    </div>
  )
}

export async function getServerSideProps() {
  const { getRecommendations } = await import('../utils/recommendations')
  const recommendations = getRecommendations(6)
  return { props: { recommendations } }
}
