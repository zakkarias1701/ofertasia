import Header from '../../components/Header'
import products from '../../data/products.json'
import { generatePriceHistory } from '../../utils/priceHistory'
import { useEffect, useState } from 'react'

export default function ProductPage({ product, history }) {
  const [affiliateLinks, setAffiliateLinks] = useState(null)

  useEffect(()=> {
    if (!product) return
    fetch(`/api/affiliate_integration?id=${product.id}`).then(r=>r.json()).then(setAffiliateLinks)
  }, [product])

  if (!product) return <div>Produto não encontrado</div>
  return (
    <div>
      <Header />
      <main className="max-w-4xl mx-auto p-6">
        <div className="flex gap-6 flex-col md:flex-row">
          <img src={product.image} className="w-full md:w-1/3 object-cover rounded" />
          <div>
            <h1 className="text-2xl font-bold">{product.title}</h1>
            <p className="text-blue-600 text-2xl font-bold mt-2">R$ {product.price.toFixed(2)}</p>
            <p className="text-sm text-gray-500 mt-2">Vendido por {product.store}</p>
            <p className="mt-4">{product.description}</p>
            <div className="mt-4 flex gap-2 flex-wrap">
              {affiliateLinks ? Object.keys(affiliateLinks.links).map(k => (
                <a key={k} href={`/api/redirect?id=${product.id}&partner=${k}`} className="px-3 py-2 bg-gray-100 rounded">{k.toUpperCase()}</a>
              )) : <span>Carregando opções...</span>}
            </div>
          </div>
        </div>

        <section className="mt-8">
          <h2 className="font-semibold">Histórico de preço (demo)</h2>
          <div className="mt-2 p-4 bg-white shadow rounded">
            <pre className="text-sm">{JSON.stringify(history, null, 2)}</pre>
          </div>
        </section>
      </main>
    </div>
  )
}

export async function getServerSideProps(context) {
  const { id } = context.params
  const product = products.find((p) => p.id === id) || null
  const history = generatePriceHistory(product ? product.price : 0)
  return { props: { product, history } }
}
