import Header from '../components/Header'
import { useEffect, useState } from 'react'

export default function AnalyticsPage(){
  const [stats, setStats] = useState(null)
  useEffect(()=> {
    fetch('/api/clicks').then(r=>r.json()).then(setStats)
  }, [])
  if (!stats) return <div><Header /><main className='p-6 max-w-4xl mx-auto'>Carregando...</main></div>
  const byProduct = stats.byProduct || {}
  const top = Object.entries(byProduct).map(([id, partners]) => {
    const total = Object.values(partners).reduce((a,b)=>a+b,0)
    return { id, total, partners }
  }).sort((a,b)=>b.total-a.total).slice(0,10)
  return (
    <div>
      <Header />
      <main className='p-6 max-w-4xl mx-auto'>
        <h1 className='text-2xl font-bold mb-4'>Analytics — Top produtos por clique</h1>
        <ul>
          {top.map(t=> <li key={t.id} className='mb-2'>Produto {t.id}: {t.total} cliques — Detalhe: {JSON.stringify(t.partners)}</li>)}
        </ul>
      </main>
    </div>
  )
}
