import fs from 'fs'
import path from 'path'
import products from '../../data/products.json'

const CLICKS = path.join(process.cwd(), 'data', 'clicks.json')

function readClicks() {
  try { return JSON.parse(fs.readFileSync(CLICKS, 'utf8')) } catch(e){ return {} }
}
function writeClicks(obj) { fs.writeFileSync(CLICKS, JSON.stringify(obj, null,2), 'utf8') }

export default function handler(req, res) {
  const id = req.query.id
  const partner = req.query.partner || 'default'
  const product = products.find(p => p.id === id)
  if (!product) return res.status(404).send('Produto não encontrado')

  const clicks = readClicks()
  clicks[id] = clicks[id] || {}
  clicks[id][partner] = (clicks[id][partner] || 0) + 1
  writeClicks(clicks)
  console.log('Clique registrado', id, partner, clicks[id][partner])

  const redirectTo = `https://example-${partner}.com/produto/${id}?affid=DEMO_${partner.toUpperCase()}`
  res.writeHead(302, { Location: redirectTo })
  return res.end()
}
