import products from '../../data/products.json'

const partners = ['mercadolivre','awin','amazon','magalu']

export default function handler(req, res) {
  const id = req.query.id
  const product = products.find(p => p.id === id)
  if (!product) return res.status(404).json({ error: 'Produto não encontrado' })

  const links = {}
  partners.forEach(partner => {
    links[partner] = `https://example-${partner}.com/produto/${id}?affid=DEMO_${partner.toUpperCase()}`
  })

  res.status(200).json({ productId: id, links })
}
