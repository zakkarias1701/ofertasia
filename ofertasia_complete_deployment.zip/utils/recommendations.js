import fs from 'fs'
import path from 'path'

export function getRecommendations(limit = 6) {
  const productsPath = path.join(process.cwd(), 'data', 'products.json')
  const clicksPath = path.join(process.cwd(), 'data', 'clicks.json')
  let products = []
  try { products = JSON.parse(fs.readFileSync(productsPath,'utf8')) } catch(e){ products = [] }
  let clicks = {}
  try { clicks = JSON.parse(fs.readFileSync(clicksPath,'utf8')) } catch(e){ clicks = {} }

  const maxClicks = Math.max(1, ...Object.values(clicks).flatMap(v => typeof v === 'object' ? Object.values(v) : v))
  products.forEach(p => {
    const c = clicks[p.id] || {}
    const totalClicks = typeof c === 'object' ? Object.values(c).reduce((a,b)=>a+b,0) : (c || 0)
    const clicksScore = totalClicks / maxClicks
    const priceScore = 1 / (1 + (p.price || 0))
    p._score = clicksScore * 0.6 + priceScore * 0.4
  })
  products.sort((a,b) => b._score - a._score)
  return products.slice(0, limit)
}
