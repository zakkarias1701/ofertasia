import Link from 'next/link'
import { Search } from 'lucide-react'
import { useRouter } from 'next/router'
import { useState } from 'react'

export default function Header() {
  const router = useRouter()
  const [q, setQ] = useState('')

  const onSearch = (e) => {
    e && e.preventDefault()
    if (!q) return
    router.push(`/search?q=${encodeURIComponent(q)}`)
  }

  return (
    <header className="w-full bg-white shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/"><a className="flex items-center gap-3"><img src="/logo.png" alt="OfertasIA" style={{height:48}}/><span className="sr-only">OfertasIA</span></a></Link>
        <form onSubmit={onSearch} className="flex items-center gap-2 w-1/2">
          <Search />
          <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Buscar produtos, marcas, modelos..." className="flex-1 border rounded px-3 py-2" />
          <button className="bg-blue-600 text-white px-4 py-2 rounded">Buscar</button>
        </form>
        <nav className="flex gap-4 text-sm text-gray-600">
          <Link href="/"><a>Home</a></Link>
          <Link href="/analytics"><a>Analytics</a></Link>
          <Link href="/admin"><a>Admin</a></Link>
        </nav>
      </div>
    </header>
  )
}
